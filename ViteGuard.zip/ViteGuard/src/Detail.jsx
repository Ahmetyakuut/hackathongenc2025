import { useLocation } from 'react-router'
import {useState, useEffect, act} from 'react'
import './App.css';
export default function Detail({props}){
    const location = useLocation()
    const lessons = location.state.lessons
    const [items, setItems] = useState(lessons)
    const cats = [...new Set(lessons.map((lesson) => lesson.cat))]
    const [activeBtn, setActiveBtn] = useState(null)
    const filteredItems = (cat) => {
        const newItems = lessons.filter((newval) => newval.cat === cat)
        setItems(newItems)
    }
    useEffect(() => {
        if(activeBtn){
            document.querySelectorAll(".lesson-btn").forEach(el => {
                el.classList.remove("active")
            })
            activeBtn.classList.add("active")
        }
    }, [activeBtn])
    return(
        <div className='lessons-container'>
            <h1>{location.state.text} Dersleri</h1>
            <Cats items={cats} filteredItems={filteredItems} setItems={setItems} lessons={lessons} setActiveBtn={setActiveBtn}></Cats>
            <div className='lessons'>
                {items && items.map((item, index) => {
                    return(
                        <a href={item.link} key={index} className='lesson'>
                            <img src={item.img} />
                            <p>{item.name}</p>
                        </a>
                    )
                })}
            </div>
        </div>
    )
}
function Cats({items, filteredItems, setItems, lessons, setActiveBtn}){
    return(
        <>
            {items.map((item, index) => (
                <button className='lesson-btn' key={index} onClick={(e) => {filteredItems(item);setActiveBtn(e.target)}}>{item}</button>
            ))}
            <button className='lesson-btn' onClick={(e) => {setItems(lessons);setActiveBtn(e.target)}}>Tümü</button>
        </>
    )
}