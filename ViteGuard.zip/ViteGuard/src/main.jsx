import { StrictMode } from 'react'
import { BrowserRouter, Router, Routes, Route } from 'react-router'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import Detail from './Detail.jsx'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
      <Routes>
        <Route path='/details' element={<Detail />}></Route>
        <Route path='/' element={<App />}></Route>
      </Routes>
  </BrowserRouter>
)
