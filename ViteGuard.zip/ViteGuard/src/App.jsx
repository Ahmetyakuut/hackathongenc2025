import './App.css';
import {Link} from 'react-router';
function App() {
  let classes = [
    {
      "img": "https://avatars.mds.yandex.net/i?id=de1ba54c55b7286963e5c12a80a6d9d9ecd65da4-5887217-images-thumbs&n=13",
      "link": "/details",
      "text": "Spor",
      "lessons": [
        {
          "name": "Yay Nasıl Tutulur",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://trthaberstatic.cdn.wp.trt.com.tr/resimler/2344000/2344311.jpg"
        },
         {
          "name": "Hentbol Nasıl Oynanır?",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://cdn-i.pr.trt.com.tr/trtspor/webp/w800/h450/q75/18539856.jpeg"
        },
        {
          "name": "Atasporlarımızda GÜREŞ",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://cdn-i.pr.trt.com.tr/trtspor/19081095.jpeg"
        },
      ]
    },
     {
      "img": "https://img.piri.net/mnresize/720/-/piri/upload/3/2024/6/25/96d7a1c5-biyoloji-konulari-1.jpg",
      "link": "/details",
      "text": "Ders",
      "lessons": [
        {
          "name": "Biyoloji(Anatomi nedir?)",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://tip.sbu.edu.tr/FileFolder/Resimler/226a44f5/2017_7/anatomi-3b4ed59e.jpeg"
        },
        {
          "name": "Matematik(Trigonometri nedir?)",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://i.ytimg.com/vi/WqbigYjQ624/maxresdefault.jpg"
        },
        {
          "name": "İngilizce(Past Continous Tense)",
          "link": "",
          "cat": "Başlangıç",
          "img": "https://i0.wp.com/ingilizce.org/wp-content/uploads/2021/04/ingilizce.org-bu%CC%88yu%CC%88k-2.png?resize=840%2C400&ssl=1"
        },
      ]
    },
  ]
  const items = classes.map((item, index) => (
    <Link key={index} to={item.link} state={item} className="class">
        <img src={item.img} />
        <h3>{item.text}</h3>
    </Link>
  ))
  return (
    <div className="App">
      <div className="title">
          <h1>360° EDUVR Eğitim Platformu</h1>
          <p>Eğlencemizi VR'a Bilgimizi Dünyaya</p>
      </div>
      <div className="classes">
          <h2>Dersler</h2>
          {items}
      </div>
    </div>
  );
}
export default App;